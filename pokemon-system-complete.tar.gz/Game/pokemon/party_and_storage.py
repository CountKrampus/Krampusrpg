"""
Party and PC Storage System
Manages active party and Pokémon storage boxes
"""

from typing import List, Optional
from .pokemon_model import Pokemon

class Party:
    """Manages active party (6 Pokémon max)"""
    
    MAX_SIZE = 6
    
    def __init__(self, player_id: int):
        self.player_id = player_id
        self.pokemon: List[Pokemon] = []
        self.lead_index = 0  # Index of lead Pokémon for battles
    
    def add(self, pokemon: Pokemon) -> bool:
        """Add Pokémon to party"""
        if len(self.pokemon) >= self.MAX_SIZE:
            return False
        self.pokemon.append(pokemon)
        return True
    
    def remove(self, index: int) -> Optional[Pokemon]:
        """Remove Pokémon from party by index"""
        if 0 <= index < len(self.pokemon):
            removed = self.pokemon.pop(index)
            # Adjust lead index if needed
            if self.lead_index >= len(self.pokemon) and len(self.pokemon) > 0:
                self.lead_index = len(self.pokemon) - 1
            return removed
        return None
    
    def swap(self, index1: int, index2: int) -> bool:
        """Swap two Pokémon in party"""
        if 0 <= index1 < len(self.pokemon) and 0 <= index2 < len(self.pokemon):
            self.pokemon[index1], self.pokemon[index2] = self.pokemon[index2], self.pokemon[index1]
            return True
        return False
    
    def set_lead(self, index: int) -> bool:
        """Set lead Pokémon for battles"""
        if 0 <= index < len(self.pokemon):
            self.lead_index = index
            return True
        return False
    
    def get_lead(self) -> Optional[Pokemon]:
        """Get lead Pokémon"""
        if 0 <= self.lead_index < len(self.pokemon):
            return self.pokemon[self.lead_index]
        return None
    
    def get_active_pokemon(self) -> List[Pokemon]:
        """Get all non-fainted Pokémon"""
        return [p for p in self.pokemon if not p.is_fainted()]
    
    def is_full(self) -> bool:
        """Check if party is full"""
        return len(self.pokemon) >= self.MAX_SIZE
    
    def is_empty(self) -> bool:
        """Check if party is empty"""
        return len(self.pokemon) == 0
    
    def to_dict(self) -> dict:
        """Convert to dictionary"""
        return {
            "player_id": self.player_id,
            "pokemon": [p.to_dict() for p in self.pokemon],
            "lead_index": self.lead_index,
            "size": len(self.pokemon),
            "max_size": self.MAX_SIZE
        }

class PokemonBox:
    """Single storage box (30 slots)"""
    
    SIZE = 30
    
    def __init__(self, name: str, box_id: int):
        self.name = name
        self.box_id = box_id
        self.pokemon: List[Optional[Pokemon]] = [None] * self.SIZE
    
    def add(self, pokemon: Pokemon, slot: Optional[int] = None) -> bool:
        """Add Pokémon to box"""
        if slot is None:
            # Find first empty slot
            for i, p in enumerate(self.pokemon):
                if p is None:
                    self.pokemon[i] = pokemon
                    return True
            return False  # Box full
        elif 0 <= slot < self.SIZE and self.pokemon[slot] is None:
            self.pokemon[slot] = pokemon
            return True
        return False
    
    def remove(self, slot: int) -> Optional[Pokemon]:
        """Remove Pokémon from box"""
        if 0 <= slot < self.SIZE:
            removed = self.pokemon[slot]
            self.pokemon[slot] = None
            return removed
        return None
    
    def get(self, slot: int) -> Optional[Pokemon]:
        """Get Pokémon from box"""
        if 0 <= slot < self.SIZE:
            return self.pokemon[slot]
        return None
    
    def get_all(self) -> List[Pokemon]:
        """Get all Pokémon in box"""
        return [p for p in self.pokemon if p is not None]
    
    def get_count(self) -> int:
        """Get number of Pokémon in box"""
        return len(self.get_all())
    
    def get_free_slots(self) -> int:
        """Get number of free slots"""
        return self.SIZE - self.get_count()
    
    def is_full(self) -> bool:
        """Check if box is full"""
        return self.get_count() >= self.SIZE
    
    def to_dict(self) -> dict:
        """Convert to dictionary"""
        return {
            "name": self.name,
            "box_id": self.box_id,
            "pokemon": [p.to_dict() if p else None for p in self.pokemon],
            "count": self.get_count(),
            "free_slots": self.get_free_slots()
        }

class KrampusPC:
    """Pokémon Storage System (PC) - 21 boxes total"""
    
    MAX_BOXES = 21
    
    def __init__(self, player_id: int):
        self.player_id = player_id
        self.boxes: List[PokemonBox] = []
        self.current_box_id = 0
        
        # Initialize boxes with names
        box_names = [
            "Box 1", "Box 2", "Box 3", "Box 4", "Box 5",
            "Box 6", "Box 7", "Box 8", "Box 9", "Box 10",
            "Box 11", "Box 12", "Box 13", "Box 14", "Box 15",
            "Box 16", "Box 17", "Box 18", "Box 19", "Box 20", "Box 21"
        ]
        
        for i, name in enumerate(box_names):
            self.boxes.append(PokemonBox(name, i))
    
    def get_current_box(self) -> PokemonBox:
        """Get current active box"""
        return self.boxes[self.current_box_id]
    
    def switch_box(self, box_id: int) -> bool:
        """Switch to different box"""
        if 0 <= box_id < len(self.boxes):
            self.current_box_id = box_id
            return True
        return False
    
    def add_pokemon(self, pokemon: Pokemon, box_id: Optional[int] = None, 
                    slot: Optional[int] = None) -> bool:
        """Add Pokémon to PC"""
        if box_id is None:
            # Find first box with space
            for box in self.boxes:
                if not box.is_full():
                    return box.add(pokemon, slot)
            return False  # All boxes full
        elif 0 <= box_id < len(self.boxes):
            return self.boxes[box_id].add(pokemon, slot)
        return False
    
    def remove_pokemon(self, box_id: int, slot: int) -> Optional[Pokemon]:
        """Remove Pokémon from PC"""
        if 0 <= box_id < len(self.boxes):
            return self.boxes[box_id].remove(slot)
        return None
    
    def move_pokemon(self, from_box: int, from_slot: int, 
                     to_box: int, to_slot: int) -> bool:
        """Move Pokémon between boxes"""
        if not (0 <= from_box < len(self.boxes) and 0 <= to_box < len(self.boxes)):
            return False
        
        pokemon = self.boxes[from_box].remove(from_slot)
        if pokemon and self.boxes[to_box].add(pokemon, to_slot):
            return True
        # Restore if move failed
        if pokemon:
            self.boxes[from_box].add(pokemon, from_slot)
        return False
    
    def get_all_pokemon(self) -> List[Pokemon]:
        """Get all Pokémon across all boxes"""
        all_pokemon = []
        for box in self.boxes:
            all_pokemon.extend(box.get_all())
        return all_pokemon
    
    def get_pokemon_count(self) -> int:
        """Get total Pokémon count"""
        return len(self.get_all_pokemon())
    
    def get_free_slots(self) -> int:
        """Get total free slots"""
        return sum(box.get_free_slots() for box in self.boxes)
    
    def find_pokemon(self, unique_id: str) -> Optional[tuple]:
        """Find Pokémon by unique ID, returns (box_id, slot) or None"""
        for box_id, box in enumerate(self.boxes):
            for slot, pokemon in enumerate(box.pokemon):
                if pokemon and pokemon.unique_id == unique_id:
                    return (box_id, slot)
        return None
    
    def to_dict(self) -> dict:
        """Convert to dictionary"""
        return {
            "player_id": self.player_id,
            "boxes": [box.to_dict() for box in self.boxes],
            "current_box_id": self.current_box_id,
            "total_pokemon": self.get_pokemon_count(),
            "free_slots": self.get_free_slots(),
            "max_boxes": self.MAX_BOXES
        }
