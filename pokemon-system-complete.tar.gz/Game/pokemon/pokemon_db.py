"""
Pokémon Database Operations
CRUD operations for Pokémon in SQLite
"""

import json
import uuid
from typing import List, Optional, Dict, Any
from Server.database import get_connection
from .pokemon_model import Pokemon, Move, Status

class PokemonDB:
    """Database operations for Pokémon"""
    
    @staticmethod
    def create_pokemon(
        owner_id: int,
        species_id: str,
        level: int = 5,
        nickname: Optional[str] = None,
        gender: str = "unknown",
        shiny: bool = False,
        variant: str = "normal",
        nature: str = "Hardy"
    ) -> Optional[Pokemon]:
        """Create and save new Pokémon to database"""
        unique_id = f"pokemon_{uuid.uuid4().hex[:12]}"
        
        pokemon = Pokemon(
            unique_id=unique_id,
            species_id=species_id,
            owner_id=owner_id,
            level=level,
            nickname=nickname or species_id.capitalize(),
            gender=gender,
            shiny=shiny,
            variant=variant,
            nature=nature
        )
        
        try:
            with get_connection() as db:
                # Insert into pokemon table
                db.execute(
                    """
                    INSERT INTO pokemon (
                        unique_id, owner_id, species_id, nickname,
                        level, experience, gender, shiny, variant,
                        nature, current_hp, max_hp, status, is_active
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        pokemon.unique_id,
                        owner_id,
                        species_id.lower(),
                        pokemon.nickname,
                        level,
                        pokemon.experience,
                        gender,
                        1 if shiny else 0,
                        variant,
                        nature,
                        pokemon.current_hp,
                        pokemon.max_hp,
                        pokemon.status.value,
                        1  # is_active
                    )
                )
                
                # Get the inserted ID
                cursor = db.execute(
                    "SELECT id FROM pokemon WHERE unique_id = ?",
                    (unique_id,)
                )
                pokemon_id = cursor.fetchone()[0]
                
                # Insert stats
                db.execute(
                    """
                    INSERT INTO pokemon_stats (
                        pokemon_id, hp_iv, attack_iv, defense_iv,
                        sp_attack_iv, sp_defense_iv, speed_iv,
                        hp_ev, attack_ev, defense_ev,
                        sp_attack_ev, sp_defense_ev, speed_ev
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    """,
                    (
                        pokemon_id,
                        pokemon.ivs.hp, pokemon.ivs.attack, pokemon.ivs.defense,
                        pokemon.ivs.sp_attack, pokemon.ivs.sp_defense, pokemon.ivs.speed,
                        pokemon.evs.hp, pokemon.evs.attack, pokemon.evs.defense,
                        pokemon.evs.sp_attack, pokemon.evs.sp_defense, pokemon.evs.speed
                    )
                )
                
                # Insert moves
                for slot, move in enumerate(pokemon.moves):
                    db.execute(
                        """
                        INSERT INTO pokemon_moves (
                            pokemon_id, move_id, slot, current_pp
                        ) VALUES (?, ?, ?, ?)
                        """,
                        (pokemon_id, move.name.lower().replace(" ", "_"), slot, move.pp)
                    )
                
                db.commit()
                return pokemon
        except Exception as e:
            print(f"Error creating Pokémon: {e}")
            return None
    
    @staticmethod
    def get_pokemon(unique_id: str) -> Optional[Pokemon]:
        """Retrieve Pokémon from database"""
        try:
            with get_connection() as db:
                cursor = db.execute(
                    """
                    SELECT p.unique_id, p.species_id, p.owner_id, p.level,
                           p.nickname, p.gender, p.shiny, p.variant,
                           p.nature, p.experience, p.current_hp, p.max_hp,
                           p.status
                    FROM pokemon p
                    WHERE p.unique_id = ?
                    """,
                    (unique_id,)
                )
                row = cursor.fetchone()
                if not row:
                    return None
                
                pokemon = Pokemon(
                    unique_id=row[0],
                    species_id=row[1],
                    owner_id=row[2],
                    level=row[3],
                    nickname=row[4],
                    gender=row[5],
                    shiny=bool(row[6]),
                    variant=row[7],
                    nature=row[8],
                    experience=row[9]
                )
                
                pokemon.current_hp = row[10]
                pokemon.status = Status(row[12])
                
                # Load stats from DB
                stats_cursor = db.execute(
                    """
                    SELECT hp_iv, attack_iv, defense_iv, sp_attack_iv,
                           sp_defense_iv, speed_iv, hp_ev, attack_ev,
                           defense_ev, sp_attack_ev, sp_defense_ev, speed_ev
                    FROM pokemon_stats
                    WHERE pokemon_id = (SELECT id FROM pokemon WHERE unique_id = ?)
                    """,
                    (unique_id,)
                )
                stats_row = stats_cursor.fetchone()
                if stats_row:
                    from .pokemon_model import PokemonIVs, PokemonEVs
                    pokemon.ivs = PokemonIVs(
                        hp=stats_row[0], attack=stats_row[1], defense=stats_row[2],
                        sp_attack=stats_row[3], sp_defense=stats_row[4], speed=stats_row[5]
                    )
                    pokemon.evs = PokemonEVs(
                        hp=stats_row[6], attack=stats_row[7], defense=stats_row[8],
                        sp_attack=stats_row[9], sp_defense=stats_row[10], speed=stats_row[11]
                    )
                    pokemon.stats = pokemon._calculate_stats()
                
                return pokemon
        except Exception as e:
            print(f"Error retrieving Pokémon: {e}")
            return None
    
    @staticmethod
    def get_player_pokemon(player_id: int) -> List[Pokemon]:
        """Get all Pokémon owned by player"""
        try:
            with get_connection() as db:
                cursor = db.execute(
                    """
                    SELECT unique_id FROM pokemon
                    WHERE owner_id = ? AND is_active = 1
                    ORDER BY created_at DESC
                    """,
                    (player_id,)
                )
                pokemon_ids = [row[0] for row in cursor.fetchall()]
                
                pokemon_list = []
                for unique_id in pokemon_ids:
                    pokemon = PokemonDB.get_pokemon(unique_id)
                    if pokemon:
                        pokemon_list.append(pokemon)
                return pokemon_list
        except Exception as e:
            print(f"Error retrieving player Pokémon: {e}")
            return []
    
    @staticmethod
    def update_pokemon(pokemon: Pokemon) -> bool:
        """Update Pokémon in database"""
        try:
            with get_connection() as db:
                db.execute(
                    """
                    UPDATE pokemon
                    SET level = ?, experience = ?, current_hp = ?,
                        max_hp = ?, status = ?, nickname = ?
                    WHERE unique_id = ?
                    """,
                    (
                        pokemon.level, pokemon.experience, pokemon.current_hp,
                        pokemon.max_hp, pokemon.status.value, pokemon.nickname,
                        pokemon.unique_id
                    )
                )
                
                # Update EVs
                db.execute(
                    """
                    UPDATE pokemon_stats
                    SET hp_ev = ?, attack_ev = ?, defense_ev = ?,
                        sp_attack_ev = ?, sp_defense_ev = ?, speed_ev = ?
                    WHERE pokemon_id = (SELECT id FROM pokemon WHERE unique_id = ?)
                    """,
                    (
                        pokemon.evs.hp, pokemon.evs.attack, pokemon.evs.defense,
                        pokemon.evs.sp_attack, pokemon.evs.sp_defense, pokemon.evs.speed,
                        pokemon.unique_id
                    )
                )
                
                db.commit()
                return True
        except Exception as e:
            print(f"Error updating Pokémon: {e}")
            return False
    
    @staticmethod
    def delete_pokemon(unique_id: str) -> bool:
        """Soft delete Pokémon (mark as inactive)"""
        try:
            with get_connection() as db:
                db.execute(
                    "UPDATE pokemon SET is_active = 0 WHERE unique_id = ?",
                    (unique_id,)
                )
                db.commit()
                return True
        except Exception as e:
            print(f"Error deleting Pokémon: {e}")
            return False
