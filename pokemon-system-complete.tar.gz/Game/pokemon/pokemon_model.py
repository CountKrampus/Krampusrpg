"""
Pokémon Model
Core Pokémon class with all attributes and methods
"""

from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Tuple
from enum import Enum
import random

from .pokemon_data import (
    get_pokemon_species,
    get_move,
    get_ability,
    get_nature_modifiers,
    NATURES
)

class Gender(Enum):
    MALE = "male"
    FEMALE = "female"
    GENDERLESS = "genderless"
    UNKNOWN = "unknown"

class Status(Enum):
    HEALTHY = "healthy"
    BURNED = "burned"
    POISONED = "poisoned"
    PARALYZED = "paralyzed"
    ASLEEP = "asleep"
    FROZEN = "frozen"
    CONFUSED = "confused"

@dataclass
class Move:
    """Represents a Pokémon move"""
    name: str
    power: int = 0
    accuracy: int = 100
    pp: int = 15
    max_pp: int = 15
    type_: str = "Normal"
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "power": self.power,
            "accuracy": self.accuracy,
            "pp": self.pp,
            "max_pp": self.max_pp,
            "type": self.type_
        }

@dataclass
class PokemonStats:
    """Pokémon base and current stats"""
    hp: int
    attack: int
    defense: int
    sp_attack: int
    sp_defense: int
    speed: int
    
    def to_dict(self) -> dict:
        return {
            "hp": self.hp,
            "attack": self.attack,
            "defense": self.defense,
            "sp_attack": self.sp_attack,
            "sp_defense": self.sp_defense,
            "speed": self.speed
        }

@dataclass
class PokemonIVs:
    """Individual Values (0-31)"""
    hp: int = field(default_factory=lambda: random.randint(0, 31))
    attack: int = field(default_factory=lambda: random.randint(0, 31))
    defense: int = field(default_factory=lambda: random.randint(0, 31))
    sp_attack: int = field(default_factory=lambda: random.randint(0, 31))
    sp_defense: int = field(default_factory=lambda: random.randint(0, 31))
    speed: int = field(default_factory=lambda: random.randint(0, 31))
    
    def to_dict(self) -> dict:
        return asdict(self)

@dataclass
class PokemonEVs:
    """Effort Values (0-252 each, max 510 total)"""
    hp: int = 0
    attack: int = 0
    defense: int = 0
    sp_attack: int = 0
    sp_defense: int = 0
    speed: int = 0
    
    def total(self) -> int:
        return sum([self.hp, self.attack, self.defense, 
                   self.sp_attack, self.sp_defense, self.speed])
    
    def to_dict(self) -> dict:
        return asdict(self)

class Pokemon:
    """Core Pokémon class"""
    
    def __init__(
        self,
        unique_id: str,
        species_id: str,
        owner_id: int,
        level: int = 5,
        nickname: Optional[str] = None,
        gender: str = "unknown",
        shiny: bool = False,
        variant: str = "normal",
        nature: str = "Hardy",
        moves: Optional[List[Move]] = None,
        ability: Optional[str] = None,
        experience: int = 0
    ):
        self.unique_id = unique_id
        self.species_id = species_id.lower()
        self.owner_id = owner_id
        self.level = level
        self.nickname = nickname
        self.gender = gender
        self.shiny = shiny
        self.variant = variant
        self.nature = nature
        self.experience = experience
        self.status = Status.HEALTHY
        self.current_hp = 1
        
        # Stats
        self.ivs = PokemonIVs()
        self.evs = PokemonEVs()
        self.stats = self._calculate_stats()
        self.max_hp = self.stats.hp
        self.current_hp = self.max_hp
        
        # Moves (max 4)
        self.moves: List[Move] = moves[:4] if moves else []
        
        # Ability
        species_data = get_pokemon_species(self.species_id)
        if ability:
            self.ability = ability
        elif species_data and "abilities" in species_data:
            self.ability = random.choice(species_data["abilities"])
        else:
            self.ability = "No Ability"
    
    def _calculate_stats(self) -> PokemonStats:
        """Calculate stats using official Pokémon formula"""
        species_data = get_pokemon_species(self.species_id)
        if not species_data or "base_stats" not in species_data:
            # Default stats if species not found
            return PokemonStats(hp=20, attack=20, defense=20, 
                              sp_attack=20, sp_defense=20, speed=20)
        
        base = species_data["base_stats"]
        nature_mods = get_nature_modifiers(self.nature)
        
        def calc_stat(stat_name: str, base_val: int, iv_val: int, ev_val: int) -> int:
            """Calculate individual stat"""
            if stat_name == "hp":
                return int((2 * base_val + iv_val + ev_val // 4) * self.level / 100 + self.level + 10)
            else:
                stat = int((2 * base_val + iv_val + ev_val // 4) * self.level / 100 + 5)
                # Apply nature modifier
                modifier = nature_mods.get(stat_name, 1.0)
                return int(stat * modifier)
        
        return PokemonStats(
            hp=calc_stat("hp", base["hp"], self.ivs.hp, self.evs.hp),
            attack=calc_stat("attack", base["attack"], self.ivs.attack, self.evs.attack),
            defense=calc_stat("defense", base["defense"], self.ivs.defense, self.evs.defense),
            sp_attack=calc_stat("sp_attack", base["sp_attack"], self.ivs.sp_attack, self.evs.sp_attack),
            sp_defense=calc_stat("sp_defense", base["sp_defense"], self.ivs.sp_defense, self.evs.sp_defense),
            speed=calc_stat("speed", base["speed"], self.ivs.speed, self.evs.speed)
        )
    
    def level_up(self, levels: int = 1) -> None:
        """Level up the Pokémon"""
        self.level = min(100, self.level + levels)
        old_hp = self.max_hp
        self.stats = self._calculate_stats()
        self.max_hp = self.stats.hp
        # Restore HP proportionally
        self.current_hp = max(1, int(self.current_hp * (self.max_hp / old_hp)))
    
    def add_experience(self, exp: int) -> None:
        """Add experience to the Pokémon"""
        self.experience += exp
        # Experience threshold: 100 * level
        if self.experience >= 100 * self.level:
            self.experience -= 100 * self.level
            self.level_up()
    
    def take_damage(self, damage: int) -> None:
        """Take damage"""
        self.current_hp = max(0, self.current_hp - damage)
    
    def heal(self, amount: int) -> None:
        """Heal HP"""
        self.current_hp = min(self.max_hp, self.current_hp + amount)
    
    def apply_status(self, status: Status) -> None:
        """Apply a status condition"""
        self.status = status
    
    def cure_status(self) -> None:
        """Cure status condition"""
        self.status = Status.HEALTHY
    
    def is_fainted(self) -> bool:
        """Check if Pokémon is fainted"""
        return self.current_hp <= 0
    
    def to_dict(self) -> dict:
        """Convert to dictionary for JSON serialization"""
        return {
            "unique_id": self.unique_id,
            "species_id": self.species_id,
            "owner_id": self.owner_id,
            "level": self.level,
            "nickname": self.nickname,
            "gender": self.gender,
            "shiny": self.shiny,
            "variant": self.variant,
            "nature": self.nature,
            "experience": self.experience,
            "status": self.status.value,
            "current_hp": self.current_hp,
            "max_hp": self.max_hp,
            "stats": self.stats.to_dict(),
            "ivs": self.ivs.to_dict(),
            "evs": self.evs.to_dict(),
            "moves": [m.to_dict() for m in self.moves],
            "ability": self.ability
        }
