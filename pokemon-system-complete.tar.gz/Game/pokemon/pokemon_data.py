"""
Pokémon Data Management
Handles species, moves, abilities, and item data
"""

import json
from pathlib import Path
from typing import Dict, List, Optional, Any

# Load game data files
DATA_DIR = Path(__file__).parent.parent.parent / "data"

def load_pokemon_species() -> Dict[str, Dict[str, Any]]:
    """Load Pokémon species data from JSON"""
    try:
        with open(DATA_DIR / "pokemon.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        # Return minimal species data if file doesn't exist
        return {
            "pikachu": {
                "id": 25,
                "name": "Pikachu",
                "type": ["Electric"],
                "base_stats": {
                    "hp": 35,
                    "attack": 55,
                    "defense": 40,
                    "sp_attack": 50,
                    "sp_defense": 50,
                    "speed": 90
                },
                "abilities": ["Static", "Lightning Rod"],
                "catch_rate": 190
            }
        }

def load_moves() -> Dict[str, Dict[str, Any]]:
    """Load move data from JSON"""
    try:
        with open(DATA_DIR / "moves.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        # Return minimal move data
        return {
            "tackle": {
                "id": 33,
                "name": "Tackle",
                "type": "Normal",
                "power": 40,
                "accuracy": 100,
                "priority": 0,
                "target": "single"
            },
            "thunderbolt": {
                "id": 24,
                "name": "Thunderbolt",
                "type": "Electric",
                "power": 90,
                "accuracy": 100,
                "priority": 0,
                "target": "single"
            }
        }

def load_abilities() -> Dict[str, Dict[str, Any]]:
    """Load ability data from JSON"""
    try:
        with open(DATA_DIR / "abilities.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        # Return minimal ability data
        return {
            "static": {
                "id": 9,
                "name": "Static",
                "description": "May paralyze on contact"
            },
            "lightning-rod": {
                "id": 31,
                "name": "Lightning Rod",
                "description": "Draws electric moves to this Pokémon"
            }
        }

def load_items() -> Dict[str, Dict[str, Any]]:
    """Load item data from JSON"""
    try:
        with open(DATA_DIR / "items.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        # Return minimal item data
        return {
            "potion": {
                "id": 1,
                "name": "Potion",
                "description": "Restores 20 HP",
                "effect": "heal_hp",
                "amount": 20
            },
            "full_restore": {
                "id": 2,
                "name": "Full Restore",
                "description": "Fully restores HP and status",
                "effect": "heal_full"
            }
        }

# Cache loaded data
POKEMON_SPECIES = load_pokemon_species()
MOVES = load_moves()
ABILITIES = load_abilities()
ITEMS = load_items()

def get_pokemon_species(species_id: str) -> Optional[Dict[str, Any]]:
    """Get Pokémon species data by ID"""
    return POKEMON_SPECIES.get(species_id.lower())

def get_move(move_id: str) -> Optional[Dict[str, Any]]:
    """Get move data by ID"""
    return MOVES.get(move_id.lower())

def get_ability(ability_id: str) -> Optional[Dict[str, Any]]:
    """Get ability data by ID"""
    return ABILITIES.get(ability_id.lower())

def get_item(item_id: str) -> Optional[Dict[str, Any]]:
    """Get item data by ID"""
    return ITEMS.get(item_id.lower())

# Nature modifiers (±10% for specific stats)
NATURES = {
    "Hardy": {},
    "Lonely": {"attack": 1.1, "defense": 0.9},
    "Brave": {"attack": 1.1, "speed": 0.9},
    "Adamant": {"attack": 1.1, "sp_attack": 0.9},
    "Naughty": {"attack": 1.1, "sp_defense": 0.9},
    "Bold": {"defense": 1.1, "attack": 0.9},
    "Docile": {},
    "Relaxed": {"defense": 1.1, "speed": 0.9},
    "Impish": {"defense": 1.1, "sp_attack": 0.9},
    "Lax": {"defense": 1.1, "sp_defense": 0.9},
    "Timid": {"speed": 1.1, "attack": 0.9},
    "Hasty": {"speed": 1.1, "defense": 0.9},
    "Serious": {},
    "Jolly": {"speed": 1.1, "sp_attack": 0.9},
    "Naive": {"speed": 1.1, "sp_defense": 0.9},
    "Modest": {"sp_attack": 1.1, "attack": 0.9},
    "Mild": {"sp_attack": 1.1, "defense": 0.9},
    "Quiet": {"sp_attack": 1.1, "speed": 0.9},
    "Bashful": {},
    "Rash": {"sp_attack": 1.1, "sp_defense": 0.9},
    "Calm": {"sp_defense": 1.1, "attack": 0.9},
    "Gentle": {"sp_defense": 1.1, "defense": 0.9},
    "Sassy": {"sp_defense": 1.1, "speed": 0.9},
    "Careful": {"sp_defense": 1.1, "sp_attack": 0.9},
    "Quirky": {}
}

def get_nature_modifiers(nature: str) -> Dict[str, float]:
    """Get stat modifiers for a nature"""
    return NATURES.get(nature, {})
