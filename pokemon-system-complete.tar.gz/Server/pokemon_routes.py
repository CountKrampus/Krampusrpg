"""
Pokémon API Routes
Endpoints for managing Pokémon, party, and PC storage
"""

from flask import Blueprint, request, jsonify, session
from Game.pokemon import Pokemon, Party, KrampusPC, PokemonDB
from .utils import current_player_id

pokemon_bp = Blueprint("pokemon", __name__, url_prefix="/api/pokemon")

# ============================================================================
# Party Management
# ============================================================================

@pokemon_bp.route("/party", methods=["GET"])
def get_party():
    """Get player's active party"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        # Load party from database
        party = Party(player_id)
        pokemon_list = PokemonDB.get_player_pokemon(player_id)
        
        # Add first 6 to party (placeholder - should use party table)
        for pokemon in pokemon_list[:6]:
            party.add(pokemon)
        
        return jsonify(party.to_dict()), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pokemon_bp.route("/party/add", methods=["POST"])
def add_to_party():
    """Add Pokémon to party"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    data = request.get_json()
    unique_id = data.get("unique_id")
    
    if not unique_id:
        return jsonify({"error": "No Pokémon specified"}), 400
    
    try:
        pokemon = PokemonDB.get_pokemon(unique_id)
        if not pokemon or pokemon.owner_id != player_id:
            return jsonify({"error": "Pokémon not found"}), 404
        
        party = Party(player_id)
        if party.add(pokemon):
            return jsonify({
                "message": "Added to party",
                "party": party.to_dict()
            }), 200
        else:
            return jsonify({"error": "Party is full"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pokemon_bp.route("/party/remove/<int:index>", methods=["DELETE"])
def remove_from_party(index):
    """Remove Pokémon from party"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        party = Party(player_id)
        # Load party from DB first
        pokemon_list = PokemonDB.get_player_pokemon(player_id)
        for pokemon in pokemon_list[:6]:
            party.add(pokemon)
        
        removed = party.remove(index)
        if removed:
            return jsonify({
                "message": "Removed from party",
                "party": party.to_dict()
            }), 200
        else:
            return jsonify({"error": "Invalid index"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ============================================================================
# PC Storage
# ============================================================================

@pokemon_bp.route("/pc", methods=["GET"])
def get_pc():
    """Get Pokémon PC (storage) contents"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        pc = KrampusPC(player_id)
        # Load all player Pokémon into PC
        all_pokemon = PokemonDB.get_player_pokemon(player_id)
        for pokemon in all_pokemon:
            pc.add_pokemon(pokemon)
        
        return jsonify(pc.to_dict()), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pokemon_bp.route("/pc/switch-box/<int:box_id>", methods=["POST"])
def switch_pc_box(box_id):
    """Switch active PC box"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        pc = KrampusPC(player_id)
        if pc.switch_box(box_id):
            return jsonify({
                "message": "Switched box",
                "current_box": pc.get_current_box().to_dict()
            }), 200
        else:
            return jsonify({"error": "Invalid box ID"}), 400
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ============================================================================
# Pokémon Management
# ============================================================================

@pokemon_bp.route("/create", methods=["POST"])
def create_pokemon():
    """Create new Pokémon"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    data = request.get_json()
    species_id = data.get("species_id", "pikachu")
    level = data.get("level", 5)
    
    try:
        pokemon = PokemonDB.create_pokemon(
            owner_id=player_id,
            species_id=species_id,
            level=level,
            nickname=data.get("nickname"),
            gender=data.get("gender", "unknown"),
            shiny=data.get("shiny", False),
            nature=data.get("nature", "Hardy")
        )
        
        if pokemon:
            return jsonify({
                "message": "Pokémon created",
                "pokemon": pokemon.to_dict()
            }), 201
        else:
            return jsonify({"error": "Failed to create Pokémon"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pokemon_bp.route("/<unique_id>", methods=["GET"])
def get_pokemon(unique_id):
    """Get Pokémon details"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        pokemon = PokemonDB.get_pokemon(unique_id)
        if not pokemon:
            return jsonify({"error": "Pokémon not found"}), 404
        
        if pokemon.owner_id != player_id:
            return jsonify({"error": "Not your Pokémon"}), 403
        
        return jsonify(pokemon.to_dict()), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pokemon_bp.route("/<unique_id>/update", methods=["POST"])
def update_pokemon(unique_id):
    """Update Pokémon"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    data = request.get_json()
    
    try:
        pokemon = PokemonDB.get_pokemon(unique_id)
        if not pokemon:
            return jsonify({"error": "Pokémon not found"}), 404
        
        if pokemon.owner_id != player_id:
            return jsonify({"error": "Not your Pokémon"}), 403
        
        # Update fields
        if "nickname" in data:
            pokemon.nickname = data["nickname"]
        if "level" in data:
            pokemon.level = data["level"]
        
        if PokemonDB.update_pokemon(pokemon):
            return jsonify({
                "message": "Pokémon updated",
                "pokemon": pokemon.to_dict()
            }), 200
        else:
            return jsonify({"error": "Update failed"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pokemon_bp.route("/<unique_id>/delete", methods=["DELETE"])
def delete_pokemon(unique_id):
    """Delete (release) Pokémon"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        pokemon = PokemonDB.get_pokemon(unique_id)
        if not pokemon:
            return jsonify({"error": "Pokémon not found"}), 404
        
        if pokemon.owner_id != player_id:
            return jsonify({"error": "Not your Pokémon"}), 403
        
        if PokemonDB.delete_pokemon(unique_id):
            return jsonify({"message": "Pokémon released"}), 200
        else:
            return jsonify({"error": "Delete failed"}), 500
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ============================================================================
# Pokédex & Species Info
# ============================================================================

@pokemon_bp.route("/species/<species_id>", methods=["GET"])
def get_species_info(species_id):
    """Get Pokémon species information"""
    from Game.pokemon import get_pokemon_species
    
    try:
        species = get_pokemon_species(species_id)
        if species:
            return jsonify(species), 200
        else:
            return jsonify({"error": "Species not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@pokemon_bp.route("/stats/summary", methods=["GET"])
def get_player_stats():
    """Get player's Pokémon statistics summary"""
    player_id = current_player_id()
    if not player_id:
        return jsonify({"error": "Not logged in"}), 401
    
    try:
        all_pokemon = PokemonDB.get_player_pokemon(player_id)
        
        return jsonify({
            "total_pokemon": len(all_pokemon),
            "average_level": sum(p.level for p in all_pokemon) / len(all_pokemon) if all_pokemon else 0,
            "total_experience": sum(p.experience for p in all_pokemon),
            "strongest": max((p.stats.attack for p in all_pokemon), default=0),
            "fastest": max((p.stats.speed for p in all_pokemon), default=0)
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
